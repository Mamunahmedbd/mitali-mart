<?php
/**
 * Class that handles specific [vc_gitem_post_meta] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_gitem_post_meta.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Gitem_Post_Meta
 */
class WPBakeryShortCode_Vc_Gitem_Post_Meta extends WPBakeryShortCode {
}
