<?php
/**
 * The template to display "Header 1"
 *
 * @package WordPress
 * @subpackage CUSTOM_MADE
 * @since CUSTOM_MADE 1.0
 */

$custom_made_header_css = $custom_made_header_image = '';
$custom_made_header_video = wp_is_mobile() ? '' : custom_made_get_theme_option('header_video');
if(!custom_made_is_on(custom_made_get_theme_option('header_hide_image'))){
	if (true || empty($custom_made_header_video)) {
		$custom_made_header_image = get_header_image();
		if (custom_made_is_on(custom_made_get_theme_option('header_image_override')) && apply_filters('custom_made_filter_allow_override_header_image', true)) {
			if (is_category()) {
				if (($custom_made_cat_img = custom_made_get_category_image()) != '')
					$custom_made_header_image = $custom_made_cat_img;
			} else if (is_singular() || custom_made_storage_isset('blog_archive')) {
				if (has_post_thumbnail()) {
					$custom_made_header_image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
					if (is_array($custom_made_header_image)) $custom_made_header_image = $custom_made_header_image[0];
				} else
					$custom_made_header_image = '';
			}
		}
	}
}
// Store header image for navi
set_query_var('custom_made_header_image', $custom_made_header_image || $custom_made_header_video);

?><header class="top_panel top_panel_default<?php
					echo !empty($custom_made_header_image) || !empty($custom_made_header_video) ? ' with_bg_image' : ' without_bg_image';
					if ($custom_made_header_video!='') echo ' with_bg_video';
					if (is_single() && has_post_thumbnail()) echo ' with_featured_image';
					?> scheme_<?php echo esc_attr(custom_made_is_inherit(custom_made_get_theme_option('header_scheme')) 
													? custom_made_get_theme_option('color_scheme') 
													: custom_made_get_theme_option('header_scheme'));
					?>">
					
	<div class="header_inner"<?php if ($custom_made_header_image!='') echo ' style="'.esc_attr('background-image: url('.esc_url($custom_made_header_image).');').'"'; ?>>
		<?php
		
		// Main menu
		if (custom_made_get_theme_option("menu_style") == 'top') {
			// Mobile menu button
			?><a class="menu_mobile_button icon-menu-2"></a><?php
			// Navigation panel
			get_template_part( 'templates/header-navi' );
		}

		// Header widgets area
		get_template_part( 'templates/header-widgets' );


		?>
	</div>
	<?php
	// Page title and breadcrumbs area
	get_template_part( 'templates/header-title');

?></header>